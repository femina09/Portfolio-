import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-cream px-6 text-center">
      <p className="font-serif font-extrabold text-7xl text-maroon">404</p>
      <p className="mt-4 text-ink-onCreamMuted">
        This page doesn&apos;t exist — the route may have moved.
      </p>
      <Link
        href="/"
        className="mt-8 inline-block bg-ink-onCream px-6 py-3 text-sm text-cream uppercase tracking-wide hover:bg-maroon transition-colors"
      >
        Back home
      </Link>
    </main>
  );
}
