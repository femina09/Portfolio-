import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { certifications } from "@/lib/data/certifications";

export const dynamicParams = false;

export function generateStaticParams() {
  return certifications.map((c) => ({ slug: c.slug }));
}

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const cert = certifications.find((c) => c.slug === slug);
  if (!cert) return {};
  return { title: cert.title, description: `${cert.title} — ${cert.issuer}${cert.date ? `, ${cert.date}` : ""}.` };
}

export default async function CertificatePage({ params }: Props) {
  const { slug } = await params;
  const cert = certifications.find((c) => c.slug === slug);
  if (!cert) notFound();

  return (
    <main className="min-h-screen px-6 py-16 md:px-10 md:py-20">
      <div className="max-w-4xl mx-auto">
        <Link href="/#certs" className="text-sm font-semibold text-maroon border-b border-current pb-0.5">
          ← All certifications
        </Link>
        {cert.category && <p className="mt-10 text-xs uppercase tracking-[0.22em] text-maroon font-semibold">{cert.category}</p>}
        <h1 className="mt-3 font-serif font-extrabold text-[clamp(1.8rem,5.2vw,3rem)] leading-tight">{cert.title}</h1>
        <p className="mt-3 text-ink-onCreamMuted">
          {cert.issuer}
          {cert.date ? ` · ${cert.date}` : ""}
        </p>
        {cert.description && <p className="mt-5 max-w-2xl leading-relaxed opacity-85">{cert.description}</p>}

        {cert.image ? (
          <>
            <div className="mt-10 border border-line-cream rounded-lg bg-white p-3 shadow-xl">
              <Image src={cert.image.src} alt={`${cert.title}, ${cert.issuer}`} width={cert.image.width} height={cert.image.height} priority className="w-full h-auto" />
            </div>
            <a href={cert.image.src} target="_blank" rel="noopener noreferrer" className="mt-5 inline-block text-sm font-semibold border-b border-current pb-0.5">
              Open full-size image →
            </a>
          </>
        ) : (
          <p className="mt-10 text-ink-onCreamMuted">The certificate image hasn’t been added yet.</p>
        )}
      </div>
    </main>
  );
}
