import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import CustomCursor from "@/components/CustomCursor";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";
import AmbientBackground from "@/components/AmbientBackground";

// Fonts are self-hosted (app/fonts) so builds never depend on reaching Google Fonts.
const inter = localFont({
  src: "./fonts/inter-latin-wght-normal.woff2",
  variable: "--font-inter",
  weight: "100 900",
  display: "swap",
});

const playfair = localFont({
  src: [
    { path: "./fonts/playfair-display-latin-wght-normal.woff2", style: "normal" },
    { path: "./fonts/playfair-display-latin-wght-italic.woff2", style: "italic" },
  ],
  variable: "--font-playfair",
  weight: "400 900",
  display: "swap",
});

const caveat = localFont({
  src: "./fonts/caveat-latin-wght-normal.woff2",
  variable: "--font-caveat",
  weight: "400 700",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://feminaportfolio.netlify.app"),
  title: {
    default: "Femina Jacob — Software Engineer | Full-Stack Developer",
    template: "%s — Femina Jacob",
  },
  description:
    "Portfolio of Femina Jacob, a final-year Computer Science and Engineering student with 1+ year of internship experience in full-stack, web, mobile, and AI/ML development.",
  keywords: [
    "Femina Jacob",
    "Software Engineer",
    "Full Stack Developer",
    "AI",
    "Machine Learning",
    "Shopify Developer",
    "React Developer",
    "Portfolio",
  ],
  authors: [{ name: "Femina Jacob" }],
  creator: "Femina Jacob",
  openGraph: {
    type: "website",
    url: "https://feminaportfolio.netlify.app",
    title: "Femina Jacob — Software Engineer | Full-Stack Developer",
    description:
      "Final-year Computer Science Engineering student building full-stack web applications, AI-powered solutions, and modern user experiences.",
    siteName: "Femina Jacob",
  },
  twitter: {
    card: "summary_large_image",
    title: "Femina Jacob — Software Engineer | Full-Stack Developer",
    description:
      "Final-year Computer Science Engineering student building full-stack web applications, AI-powered solutions, and modern user experiences.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${playfair.variable} ${caveat.variable} font-body antialiased bg-cream text-ink-onCream`}
      >
        <CustomCursor />
        <AmbientBackground />
        <ScrollProgress />
        <BackToTop />
        {children}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Person",
              name: "Femina Jacob",
              jobTitle: "Software Engineer",
              url: "https://feminaportfolio.netlify.app",
              sameAs: [
                "https://github.com/femina09",
                "https://www.linkedin.com/in/femina-jacob",
              ],
              alumniOf: {
                "@type": "CollegeOrUniversity",
                name: "Grace College of Engineering",
              },
            }),
          }}
        />
      </body>
    </html>
  );
}
