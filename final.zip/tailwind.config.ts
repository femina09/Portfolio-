import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        cream: "#F3ECE1",
        dark: "#14110F",
        maroon: {
          DEFAULT: "#7A2036",
          soft: "#9A3B52",
        },
        mustard: "#D8A94E",
        ink: {
          onCream: "#1C1710",
          onCreamMuted: "#8A7F6F",
          onDark: "#F3ECE1",
          onDarkMuted: "#B9AFA0",
        },
        line: {
          cream: "rgba(28,23,16,0.12)",
          dark: "rgba(243,236,225,0.14)",
        },
      },
      fontFamily: {
        serif: ["var(--font-playfair)", "Georgia", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
        hand: ["var(--font-caveat)", "cursive"],
      },
    },
  },
  plugins: [],
};

export default config;
