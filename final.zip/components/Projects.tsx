"use client";

import { useState } from "react";
import clsx from "clsx";
import { caseStudies } from "@/lib/data/projects";
import CaseStudySection from "./CaseStudySection";

const categories = ["All", ...Array.from(new Set(caseStudies.map((c) => c.category)))];

export default function Projects() {
  const [active, setActive] = useState("All");
  const list = caseStudies.filter((c) => active === "All" || c.category === active);

  return (
    <>
      <section id="projects" className="px-6 pt-24 pb-10 md:px-10 md:pt-28">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <h2 className="font-serif font-bold text-[clamp(1.7rem,5.4vw,2.9rem)]">Selected projects</h2>
            <p className="font-hand text-[clamp(1.05rem,3vw,1.35rem)] text-maroon">— newest first</p>
          </div>
          <div role="group" aria-label="Filter projects by category" className="flex flex-wrap gap-2.5">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={active === c}
                onClick={() => setActive(c)}
                className={clsx(
                  "btn-3d [--depth:rgba(122,32,54,0.25)] border rounded-full px-4 py-2 text-xs uppercase tracking-wide",
                  active === c ? "bg-ink-onCream text-cream border-ink-onCream" : "border-line-cream hover:border-maroon hover:text-maroon"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </section>
      {list.map((project, i) => (
        <CaseStudySection key={project.slug} project={project} dark={i % 2 === 0} reverse={i % 2 === 1} />
      ))}
    </>
  );
}
