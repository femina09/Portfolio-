"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import clsx from "clsx";
import { certCategories, certifications, type Certification } from "@/lib/data/certifications";
import { achievements } from "@/lib/data/site";
import TiltCard from "./TiltCard";
import CertificateViewer from "./CertificateViewer";

const INITIAL = 6;
const GRID = "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-[18px]";

function CertCard({ cert, onView }: { cert: Certification; onView: () => void }) {
  return (
    <TiltCard lift={6} className="cert-card h-full flex flex-col border border-line-cream rounded-lg bg-white overflow-hidden hover:shadow-lg transition-shadow">
      {cert.image ? (
        <button
          type="button"
          onClick={onView}
          aria-label={`View ${cert.title} certificate`}
          className="block relative aspect-[3/2] bg-cream border-b border-line-cream"
        >
          <Image
            src={cert.image.src}
            alt={`${cert.title} certificate preview`}
            fill
            sizes="(min-width:1024px) 330px, (min-width:640px) 45vw, 92vw"
            className="object-contain p-2"
          />
        </button>
      ) : (
        <div className="aspect-[3/2] bg-cream border-b border-line-cream flex flex-col items-center justify-center gap-2">
          <div className="w-12 h-12 rounded-full bg-maroon/10 text-maroon flex items-center justify-center text-sm font-bold">{cert.initials}</div>
          <p className="text-[10px] uppercase tracking-wider text-ink-onCreamMuted">Certificate image not added yet</p>
        </div>
      )}
      <div className="p-5 flex flex-col flex-1">
        {cert.category && <p className="text-[10px] uppercase tracking-wider font-bold text-maroon">{cert.category}</p>}
        <p className="font-bold text-sm mt-1.5 leading-snug">{cert.title}</p>
        <p className="text-xs text-ink-onCreamMuted mt-1">{cert.issuer}</p>
        {cert.date && <p className="text-xs text-ink-onCreamMuted mt-0.5">{cert.date}</p>}
        {cert.image && (
          <button type="button" onClick={onView} className="mt-auto pt-4 self-start text-xs font-semibold text-maroon border-b border-current pb-0.5">
            View Certificate →
          </button>
        )}
      </div>
    </TiltCard>
  );
}

export default function Certifications() {
  const [category, setCategory] = useState<string>("All");
  const [expanded, setExpanded] = useState(false);
  const [viewIdx, setViewIdx] = useState<number | null>(null);

  const filtered = useMemo(() => certifications.filter((c) => category === "All" || c.category === category), [category]);
  const viewable = useMemo(() => filtered.filter((c) => c.image), [filtered]);
  const first = filtered.slice(0, INITIAL);
  const rest = filtered.slice(INITIAL);
  const cats = ["All", ...certCategories.filter((c) => certifications.some((x) => x.category === c))];

  const open = (c: Certification) => setViewIdx(viewable.findIndex((v) => v.slug === c.slug));
  const toggle = () => {
    if (expanded) document.getElementById("cert-grid")?.scrollIntoView({ behavior: "smooth", block: "start" });
    setExpanded((e) => !e);
  };

  return (
    <section id="certs" className="px-6 py-24 md:px-10 md:py-28">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <h2 className="font-serif font-bold text-[clamp(1.7rem,5.4vw,2.9rem)]">Certifications</h2>
          <p className="font-hand text-[clamp(1.05rem,3vw,1.35rem)] text-maroon">— credentials worth listing</p>
        </div>

        <div role="group" aria-label="Filter certifications by category" className="flex flex-wrap gap-2.5 mb-8">
          {cats.map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={category === c}
              onClick={() => {
                setCategory(c);
                setExpanded(false);
              }}
              className={clsx(
                "btn-3d [--depth:rgba(122,32,54,0.25)] border rounded-full px-4 py-2 text-xs uppercase tracking-wide",
                category === c ? "bg-ink-onCream text-cream border-ink-onCream" : "border-line-cream hover:border-maroon hover:text-maroon"
              )}
            >
              {c}
            </button>
          ))}
        </div>

        <div id="cert-grid" className="scroll-mt-28">
          <div className={GRID}>
            {first.map((cert, i) => (
              <motion.div key={cert.slug} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
                <CertCard cert={cert} onView={() => open(cert)} />
              </motion.div>
            ))}
          </div>

          <AnimatePresence initial={false}>
            {expanded && rest.length > 0 && (
              <motion.div
                id="cert-more"
                key="more"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.45, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <div className={`${GRID} pt-[18px] pb-3`}>
                  {rest.map((cert) => (
                    <div key={cert.slug}>
                      <CertCard cert={cert} onView={() => open(cert)} />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {rest.length > 0 && (
          <div className="mt-8 flex justify-center">
            <button
              type="button"
              aria-expanded={expanded}
              aria-controls="cert-more"
              onClick={toggle}
              className="btn-3d [--depth:#7A2036] inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold uppercase tracking-wide bg-ink-onCream text-cream hover:bg-maroon"
            >
              {expanded ? "Show Less" : `Show All Certificates (${filtered.length})`}
            </button>
          </div>
        )}
        {filtered.length === 0 && <p className="text-ink-onCreamMuted">No certificates in this category yet.</p>}

        <h3 className="font-serif font-bold text-[clamp(1.4rem,4vw,2rem)] mt-16 mb-6">Achievements</h3>
        <div className="flex flex-col">
          {achievements.map((a) => (
            <motion.div
              key={a.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-1 sm:grid-cols-[170px_1fr] gap-1 sm:gap-6 border-t border-line-cream py-5"
            >
              <p className="font-serif italic text-maroon">{a.label}</p>
              <p>
                <span className="font-bold text-sm">{a.title}</span>
                <span className="text-ink-onCreamMuted text-sm"> — {a.detail}</span>
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      {viewIdx !== null && viewIdx >= 0 && (
        <CertificateViewer items={viewable} index={viewIdx} onIndex={setViewIdx} onClose={() => setViewIdx(null)} />
      )}
    </section>
  );
}
