"use client";

import { useEffect, useRef } from "react";

/**
 * Minimal ambient background (2D canvas, no libraries): tiny drifting bubbles, soft glowing dots,
 * a few thin curved lines and an almost imperceptible warm glow. It sits between the section
 * backgrounds and the page content, never takes pointer events, and re-tints smoothly according to
 * the real background of the section behind each particle: muted gold / beige / dusty rose on cream,
 * bronze / warm gold / champagne on dark.
 */

type RGB = [number, number, number];
const hex = (h: string): RGB => {
  const v = h.replace("#", "").trim();
  const n = parseInt(v.length === 3 ? v.split("").map((c) => c + c).join("") : v, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const mixC = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const rgba = (c: RGB, a: number) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a.toFixed(3)})`;

// small seeded PRNG so the composition is identical on every load
const rng = (seed: number) => () => {
  seed = (seed * 16807) % 2147483647;
  return (seed - 1) / 2147483646;
};

interface Particle {
  bubble: boolean;
  x: number; // 0..1 across the viewport
  y: number; // 0..1 down the viewport
  r: number;
  depth: number; // scroll parallax
  speed: number; // px/s upward drift
  sway: number;
  phase: number;
  alpha: number;
  tone: 0 | 1 | 2;
  theme: number; // 0 = cream section, 1 = dark section (smoothed)
}
interface Line {
  y: number; // document y
  x: number;
  w: number;
  h: [number, number, number];
  phase: number;
  tone: 0 | 1;
  theme: number;
}
interface Sec {
  top: number;
  bottom: number;
  dark: number;
}

export default function AmbientBackground() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const mobile = innerWidth < 768;

    // ---- palette from the site's CSS variables
    const cs = getComputedStyle(document.documentElement);
    const v = (n: string, f: string) => hex(cs.getPropertyValue(n).trim() || f);
    const cream = v("--color-cream", "#F3ECE1");
    const dark = v("--color-dark", "#14110F");
    const maroon = v("--color-maroon", "#7A2036");
    const maroonSoft = v("--color-maroon-soft", "#9A3B52");
    const mustard = v("--color-mustard", "#D8A94E");
    // cream sections: muted gold, soft beige, dusty rose
    const LIGHT: RGB[] = [mixC(mustard, maroon, 0.12), mixC(cream, dark, 0.3), mixC(cream, maroonSoft, 0.5)];
    // dark sections: warm gold, muted bronze, soft champagne
    const DARK: RGB[] = [mustard, mixC(mustard, maroon, 0.45), mixC(mustard, cream, 0.6)];
    const GLOW_L = mixC(mustard, cream, 0.4);
    const GLOW_D = mixC(mustard, maroon, 0.3);

    // ---- composition
    const rand = rng(20261111);
    const nBubble = mobile ? 7 : 12;
    const nDot = mobile ? 16 : 28;
    const particles: Particle[] = [];
    for (let i = 0; i < nBubble + nDot; i++) {
      const bubble = i < nBubble;
      particles.push({
        bubble,
        x: rand(),
        y: rand(),
        r: bubble ? 2.8 + rand() * 3.6 : 0.9 + rand() * 1.4,
        depth: 0.15 + rand() * 0.5,
        speed: bubble ? 5 + rand() * 7 : 1.5 + rand() * 3,
        sway: 6 + rand() * 12,
        phase: rand() * 6.28,
        alpha: bubble ? 0.7 + rand() * 0.3 : 0.6 + rand() * 0.4,
        tone: (Math.floor(rand() * 3) % 3) as 0 | 1 | 2,
        theme: 0,
      });
    }
    let lines: Line[] = [];
    let secs: Sec[] = [];
    let W = 0;
    let H = 0;
    let pageH = 1;
    let glowTheme = 0;

    const layout = () => {
      const dpr = Math.min(devicePixelRatio || 1, mobile ? 1.25 : 1.5);
      W = innerWidth;
      H = innerHeight;
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      pageH = Math.max(document.documentElement.scrollHeight, H);
      secs = Array.from(document.querySelectorAll("main section, main footer")).map((el) => {
        const r = el.getBoundingClientRect();
        const m = getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
        const [rr, gg, bb, aa] = m ? m.map(Number) : [255, 255, 255, 0];
        const isDark = aa === 0 ? 0 : 0.2126 * rr + 0.7152 * gg + 0.0722 * bb < 110 ? 1 : 0;
        return { top: r.top + scrollY, bottom: r.bottom + scrollY, dark: isDark };
      });
      const lr = rng(77);
      const nLines = mobile ? 4 : 6;
      lines = Array.from({ length: nLines }, (_, i) => ({
        y: ((i + 0.3 + lr() * 0.5) / nLines) * pageH,
        x: lr() * W * 0.55,
        w: W * (0.3 + lr() * 0.3),
        h: [(lr() - 0.5) * 140, (lr() - 0.5) * 140, (lr() - 0.5) * 100],
        phase: lr() * 6.28,
        tone: (i % 2) as 0 | 1,
        theme: 0,
      }));
    };
    const themeAt = (docY: number) => {
      for (const s of secs) if (docY >= s.top && docY < s.bottom) return s.dark;
      return 0;
    };

    const smooth = (a: number, b: number, x: number) => {
      const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
      return t * t * (3 - 2 * t);
    };
    const col = (tones: [RGB[], RGB[]], tone: number, theme: number) => mixC(tones[0][tone], tones[1][tone], theme);

    const draw = (t: number, dt: number) => {
      ctx.clearRect(0, 0, W, H);
      const sy0 = scrollY;
      const k = Math.min(1, dt * 2.2); // slow theme transitions

      // almost imperceptible warm ambient light
      glowTheme += (themeAt(sy0 + H / 2) - glowTheme) * k;
      const gc = mixC(GLOW_L, GLOW_D, glowTheme);
      const ga = 0.05 + 0.02 * glowTheme;
      const gx = W * (0.78 + Math.sin(t * 0.03) * 0.04);
      const gy = H * (0.22 + Math.cos(t * 0.025) * 0.04);
      const rad = Math.min(W, H) * 0.7;
      const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, rad);
      g.addColorStop(0, rgba(gc, ga));
      g.addColorStop(1, rgba(gc, 0));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);

      // thin curved lines (document space, gentle depth)
      ctx.lineWidth = 0.9;
      ctx.lineCap = "round";
      for (const l of lines) {
        const sy = l.y - sy0 * 0.92;
        if (sy < -220 || sy > H + 220) continue;
        l.theme += (themeAt(sy + sy0) - l.theme) * k;
        const c = col([LIGHT, DARK], l.tone === 0 ? 0 : 2, l.theme);
        const sw = Math.sin(t * 0.05 + l.phase) * 8;
        const fade = smooth(-200, 40, sy) * (1 - smooth(H - 40, H + 200, sy));
        ctx.strokeStyle = rgba(c, (0.28 + 0.06 * l.theme) * fade);
        ctx.beginPath();
        ctx.moveTo(l.x, sy);
        ctx.bezierCurveTo(l.x + l.w * 0.3, sy + l.h[0] + sw, l.x + l.w * 0.65, sy + l.h[1] - sw, l.x + l.w, sy + l.h[2]);
        ctx.stroke();
      }

      // bubbles + dots
      const span = H + 60;
      for (const p of particles) {
        const raw = p.y * H - t * p.speed - sy0 * p.depth * 0.2;
        const sy = ((raw % span) + span) % span - 30;
        const sx = p.x * W + Math.sin(t * 0.12 + p.phase) * p.sway;
        p.theme += (themeAt(sy + sy0) - p.theme) * k;
        const c = col([LIGHT, DARK], p.tone, p.theme);
        const edge = smooth(-30, 70, sy) * (1 - smooth(H - 70, H + 30, sy));
        const tw = p.bubble ? 1 : 0.65 + 0.35 * Math.sin(t * 0.35 + p.phase * 3);
        const a = p.alpha * edge * tw * (0.8 + 0.2 * p.theme);
        if (a < 0.01) continue;
        if (p.bubble) {
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(sx, sy, p.r, 0, 6.2832);
          ctx.fillStyle = rgba(c, a * 0.08);
          ctx.fill();
          ctx.strokeStyle = rgba(c, a * 0.7);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(sx, sy, p.r * 0.62, Math.PI * 1.08, Math.PI * 1.45);
          ctx.strokeStyle = rgba(mixC(c, [255, 252, 245], 0.6), a * 0.85);
          ctx.stroke();
        } else {
          ctx.beginPath();
          ctx.arc(sx, sy, p.r * 3.2, 0, 6.2832);
          ctx.fillStyle = rgba(c, a * 0.12);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(sx, sy, p.r, 0, 6.2832);
          ctx.fillStyle = rgba(c, a);
          ctx.fill();
        }
      }
    };

    layout();
    let raf = 0;
    let last = performance.now();
    const t0 = last;
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (now - last < 33) return; // ~30 fps is plenty for slow drift and saves battery
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      draw((now - t0) / 1000, dt);
    };
    const redrawOnce = () => {
      // reduced motion: static composition, re-tinted as sections scroll past
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        for (let i = 0; i < 6; i++) draw(8, 1);
      });
    };
    const onResize = () => {
      layout();
      if (reduce) redrawOnce();
    };
    addEventListener("resize", onResize);
    const ro = new ResizeObserver(onResize);
    ro.observe(document.body);
    const onVis = () => {
      cancelAnimationFrame(raf);
      if (!document.hidden && !reduce) {
        last = performance.now();
        raf = requestAnimationFrame(frame);
      }
    };
    document.addEventListener("visibilitychange", onVis);
    if (reduce) {
      addEventListener("scroll", redrawOnce, { passive: true });
      redrawOnce();
    } else raf = requestAnimationFrame(frame);
    canvas.style.opacity = "1";

    return () => {
      cancelAnimationFrame(raf);
      removeEventListener("resize", onResize);
      removeEventListener("scroll", redrawOnce);
      document.removeEventListener("visibilitychange", onVis);
      ro.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="fixed inset-0 w-full h-full pointer-events-none z-[5] opacity-0 transition-opacity duration-[1500ms]"
    />
  );
}
