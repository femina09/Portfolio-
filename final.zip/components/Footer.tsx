export default function Footer() {
  return (
    <footer className="border-t border-line-cream px-6 py-8 md:px-10 flex flex-wrap items-center justify-between gap-3.5 text-sm">
      <p>Building intelligent software that creates meaningful impact.</p>
      <a href="#hero" className="hover:text-maroon transition-colors">
        Back to top ↑
      </a>
    </footer>
  );
}
