"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import type { Certification } from "@/lib/data/certifications";

const ZOOMS = [1, 1.5, 2, 3];

export default function CertificateViewer({
  items,
  index,
  onIndex,
  onClose,
}: {
  items: Certification[];
  index: number;
  onIndex: (i: number) => void;
  onClose: () => void;
}) {
  const [zoom, setZoom] = useState(0);
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const cert = items[index];
  const n = items.length;

  const go = useCallback((d: number) => onIndex((index + d + n) % n), [index, n, onIndex]);
  const zoomBy = useCallback((d: number) => setZoom((z) => Math.max(0, Math.min(ZOOMS.length - 1, z + d))), []);

  useEffect(() => setZoom(0), [index]);

  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
      opener?.focus?.();
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowRight" && n > 1) go(1);
      else if (e.key === "ArrowLeft" && n > 1) go(-1);
      else if (e.key === "+" || e.key === "=") zoomBy(1);
      else if (e.key === "-") zoomBy(-1);
      else if (e.key === "Tab" && dialogRef.current) {
        const f = dialogRef.current.querySelectorAll<HTMLElement>("button, a[href]");
        if (!f.length) return;
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [go, zoomBy, onClose, n]);

  if (!cert?.image) return null;
  const z = ZOOMS[zoom];
  const btn =
    "btn-3d [--depth:rgba(243,236,225,0.25)] w-10 h-10 rounded-full border border-line-dark text-ink-onDark hover:border-mustard hover:text-mustard flex items-center justify-center disabled:opacity-30 disabled:pointer-events-none";

  return (
    <div
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-label={`${cert.title} certificate`}
      className="fixed inset-0 z-[200] bg-dark/95 text-ink-onDark flex flex-col"
    >
      <div className="flex items-center justify-between gap-4 px-4 py-3 md:px-8 border-b border-line-dark">
        <div className="min-w-0">
          <p className="font-serif font-bold truncate">{cert.title}</p>
          <p className="text-xs text-ink-onDarkMuted truncate">
            {cert.issuer}
            {cert.date ? ` · ${cert.date}` : ""} · {index + 1} / {n}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button type="button" className={btn} aria-label="Zoom out" onClick={() => zoomBy(-1)} disabled={zoom === 0}>
            −
          </button>
          <button type="button" className={btn} aria-label="Zoom in" onClick={() => zoomBy(1)} disabled={zoom === ZOOMS.length - 1}>
            +
          </button>
          <a href={`/certifications/${cert.slug}`} className={`${btn} text-xs`} aria-label="Open certificate page" title="Open certificate page">
            ↗
          </a>
          <button ref={closeRef} type="button" className={btn} aria-label="Close viewer" onClick={onClose}>
            ✕
          </button>
        </div>
      </div>

      <div className="relative flex-1 min-h-0">
        <div
          className="absolute inset-0 overflow-auto flex p-4 md:p-8"
          onClick={(e) => e.target === e.currentTarget && onClose()}
        >
          <Image
            key={cert.slug}
            src={cert.image.src}
            width={cert.image.width}
            height={cert.image.height}
            unoptimized
            alt={`${cert.title}, ${cert.issuer}`}
            onClick={() => setZoom((v) => (v === 0 ? 2 : 0))}
            className={z === 1 ? "m-auto max-h-full max-w-full w-auto h-auto object-contain cursor-zoom-in shadow-2xl" : "m-auto h-auto max-w-none cursor-zoom-out shadow-2xl"}
            style={z === 1 ? undefined : { width: `${z * 100}%` }}
          />
        </div>
        {n > 1 && (
          <>
            <button type="button" aria-label="Previous certificate" onClick={() => go(-1)} className={`${btn} absolute left-3 top-1/2 -translate-y-1/2 bg-dark/70`}>
              ←
            </button>
            <button type="button" aria-label="Next certificate" onClick={() => go(1)} className={`${btn} absolute right-3 top-1/2 -translate-y-1/2 bg-dark/70`}>
              →
            </button>
          </>
        )}
      </div>
    </div>
  );
}
