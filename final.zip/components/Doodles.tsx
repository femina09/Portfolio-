import type { CSSProperties } from "react";

export function ArrowDoodle({ className = "", color = "text-maroon" }: { className?: string; color?: string }) {
  return (
    <svg className={`${className} ${color}`} viewBox="0 0 80 44" fill="none" width="52" height="34">
      <path d="M4 32 C 22 10, 50 6, 68 18" stroke="currentColor" strokeWidth="3.2" fill="none" strokeLinecap="round" />
      <path d="M52 8 L70 18 L54 30" stroke="currentColor" strokeWidth="3.2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function StarDoodle({ className = "", color = "text-mustard" }: { className?: string; color?: string }) {
  return (
    <svg className={`${className} ${color}`} viewBox="0 0 60 60" fill="none" width="48">
      <path
        d="M30 4 L34 24 L54 28 L34 32 L30 52 L26 32 L6 28 L26 24 Z"
        fill="currentColor"
        opacity="0.7"
      />
    </svg>
  );
}

export function CircleScribble({ className = "", style }: { className?: string; style?: CSSProperties }) {
  return (
    <svg className={className} style={style} viewBox="0 0 310 310" fill="none">
      <path
        d="M155 12 C 230 14, 292 72, 296 152 C 300 232, 238 296, 156 298 C 74 300, 14 236, 12 154 C 10 74, 78 10, 155 12 Z"
        stroke="#7A2036"
        strokeWidth="2.5"
        strokeLinecap="round"
        opacity="0.55"
      />
    </svg>
  );
}
