"use client";

import { useRef } from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import { galleryItems } from "@/lib/data/projects";
import TiltCard from "./TiltCard";

export default function Gallery() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: number) => {
    scrollRef.current?.scrollBy({ left: dir * 310, behavior: "smooth" });
  };

  return (
    <section id="gallery" className="py-20 md:py-24">
      <div className="max-w-5xl mx-auto px-6 md:px-10 flex flex-wrap items-end justify-between gap-4 mb-9">
        <h2 className="font-serif font-bold text-[clamp(1.7rem,5.4vw,2.9rem)]">More work</h2>
        <p className="font-hand text-[clamp(1.05rem,3vw,1.35rem)] text-maroon">— drag or scroll sideways →</p>
      </div>
      <div className="flex gap-3 px-6 md:px-10 mb-3">
        <button
          onClick={() => scroll(-1)}
          aria-label="Scroll left"
          className="btn-3d w-10 h-10 rounded-full border border-line-cream flex items-center justify-center hover:border-maroon hover:text-maroon"
        >
          ←
        </button>
        <button
          onClick={() => scroll(1)}
          aria-label="Scroll right"
          className="btn-3d w-10 h-10 rounded-full border border-line-cream flex items-center justify-center hover:border-maroon hover:text-maroon"
        >
          →
        </button>
      </div>
      <div ref={scrollRef} className="flex gap-5 overflow-x-auto px-6 md:px-10 pb-6" style={{ scrollSnapType: "x mandatory" }}>
        {galleryItems.map((item, i) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            className="flex-none w-[280px]"
            style={{ scrollSnapAlign: "start" }}
          >
            <TiltCard lift={8} className="h-card h-full border border-line-cream rounded-lg overflow-hidden bg-white hover:shadow-xl transition-shadow">
            <div className="relative h-[130px] bg-gradient-to-br from-maroon/10 to-mustard/5">
              {item.image ? (
                <Image src={item.image} alt={item.title} fill sizes="280px" className="object-cover object-top" />
              ) : (
                <div className="h-full flex items-center justify-center">
                  <span className="font-serif opacity-30 text-sm text-center px-4">{item.title}<br /><span className="text-[10px] font-body uppercase tracking-wider">Screenshot coming soon</span></span>
                </div>
              )}
            </div>
            <div className="p-[18px]">
              <p className="font-bold text-sm">{item.title}</p>
              <p className="text-xs text-ink-onCreamMuted mt-1.5">{item.label}</p>
              <div className="mt-3 text-xs">
                {item.anchor && (
                  <a href={item.anchor} className="text-maroon font-semibold">
                    View Case Study →
                  </a>
                )}
                {item.repoUrl && (
                  <a href={item.repoUrl} target="_blank" rel="noopener noreferrer" className="text-maroon font-semibold">
                    View Repository →
                  </a>
                )}
                {item.liveUrl && (
                  <a href={item.liveUrl} target="_blank" rel="noopener noreferrer" className="text-maroon font-semibold">
                    Visit Live Site →
                  </a>
                )}
                {item.comingSoon && <span className="opacity-40">Coming soon</span>}
              </div>
            </div>
            </TiltCard>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
