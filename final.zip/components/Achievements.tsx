"use client";

import { motion } from "framer-motion";
import { stats } from "@/lib/data/site";
import AnimatedStat from "./AnimatedStat";

export default function Achievements() {
  return (
    <section id="achieve" className="sec-dark bg-dark text-ink-onDark px-6 py-24 md:px-10 md:py-28 text-center">
      <p className="text-xs uppercase tracking-[0.22em] text-mustard font-semibold flex justify-center mb-3">
        By the numbers
      </p>
      <h2 className="font-serif font-bold text-[clamp(1.6rem,5.6vw,2.6rem)]">
        Learning every day. Building every semester.
      </h2>
      <div className="max-w-3xl mx-auto mt-12 grid grid-cols-2 sm:grid-cols-3 gap-7 sm:gap-5">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.06 }}
          >
            <p className={stat.text ? "font-serif font-extrabold text-mustard text-[clamp(1.3rem,4.6vw,2rem)]" : "font-serif font-extrabold text-mustard text-[clamp(1.9rem,6.6vw,3rem)]"}>
              {stat.text ?? <AnimatedStat value={stat.value ?? 0} suffix={stat.suffix} />}
            </p>
            <p className="mt-2 text-xs uppercase tracking-wider text-ink-onDarkMuted">{stat.label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
