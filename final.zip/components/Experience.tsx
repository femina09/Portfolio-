"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { experiences } from "@/lib/data/site";
import TiltCard from "./TiltCard";

export default function Experience() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  return (
    <section id="experience" className="sec-dark bg-dark text-ink-onDark px-6 py-24 md:px-10 md:py-28">
      <div className="max-w-5xl mx-auto">
        <p className="text-xs uppercase tracking-[0.22em] text-mustard font-semibold mb-3">Experience</p>
        <h2 className="font-serif font-bold text-[clamp(1.7rem,5.4vw,2.9rem)]">Experience &amp; internships</h2>
        <div className="mt-12 flex flex-col">
          {experiences.map((e, i) => {
            const open = openIdx === i;
            return (
              <motion.div
                key={e.role + e.org}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
              >
                <TiltCard max={2.5} lift={4} className="grid grid-cols-1 sm:grid-cols-[190px_1fr] gap-2 sm:gap-8 border-t border-line-dark py-7">
                <p className="font-serif italic text-mustard text-lg leading-snug">{e.dates}</p>
                <div>
                  <h3 className="font-serif font-bold text-xl">{e.role}</h3>
                  <p className="text-ink-onDarkMuted mt-1">{e.org}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {e.tags.map((t) => (
                      <span key={t} className="border border-line-dark rounded-sm px-3 py-1 text-xs uppercase tracking-wide">
                        {t}
                      </span>
                    ))}
                  </div>
                  <motion.ul
                    initial={false}
                    animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }}
                    transition={{ duration: 0.35 }}
                    className="overflow-hidden list-disc pl-5 text-[#e7e0d3] text-[0.95rem] leading-relaxed"
                    id={`exp-${i}`}
                  >
                    {e.details.map((d, k) => (
                      <li key={d} className={k === 0 ? "mt-4" : "mt-1.5"}>
                        {d}
                      </li>
                    ))}
                  </motion.ul>
                  <div className="mt-4 flex flex-wrap gap-6 text-sm font-semibold">
                    <button
                      type="button"
                      aria-expanded={open}
                      aria-controls={`exp-${i}`}
                      onClick={() => setOpenIdx(open ? null : i)}
                      className="border-b border-current pb-0.5 text-mustard"
                    >
                      {open ? "Hide details −" : "Show details +"}
                    </button>
                    {e.link && (
                      <a href={e.link.href} target="_blank" rel="noopener noreferrer" className="border-b border-current pb-0.5">
                        {e.link.label} →
                      </a>
                    )}
                  </div>
                </div>
                </TiltCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
