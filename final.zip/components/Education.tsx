"use client";

import { motion } from "framer-motion";
import { education } from "@/lib/data/site";
import TiltCard from "./TiltCard";

export default function Education() {
  return (
    <section id="education" className="px-6 py-24 md:px-10 md:py-28 border-t border-line-cream">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-9">
          <h2 className="font-serif font-bold text-[clamp(1.7rem,5.4vw,2.9rem)]">Education</h2>
          <p className="font-hand text-[clamp(1.05rem,3vw,1.35rem)] text-maroon">— where it started</p>
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <TiltCard max={3} className="border border-line-cream rounded-lg bg-white p-6 md:p-8">
          <p className="font-serif italic text-maroon">{education.years}</p>
          <h3 className="font-serif font-bold text-2xl mt-1">{education.degree}</h3>
          <p className="text-ink-onCreamMuted mt-1">{education.school}</p>
          <p className="mt-6 text-xs uppercase tracking-wider font-bold text-maroon">Relevant coursework</p>
          <div className="mt-3 flex flex-wrap gap-2.5">
            {education.coursework.map((c) => (
              <span key={c} className="border border-line-cream rounded-sm px-3 py-1.5 text-xs uppercase tracking-wide">
                {c}
              </span>
            ))}
          </div>
          </TiltCard>
        </motion.div>
      </div>
    </section>
  );
}
