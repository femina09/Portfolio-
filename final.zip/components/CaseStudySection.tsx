"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import clsx from "clsx";
import type { CaseStudy } from "@/lib/data/projects";
import { ArrowDoodle, StarDoodle } from "./Doodles";
import TiltCard from "./TiltCard";

export default function CaseStudySection({
  project,
  dark: isDark,
  reverse,
}: {
  project: CaseStudy;
  dark: boolean;
  reverse: boolean;
}) {
  const [open, setOpen] = useState(false);
  const Doodle = isDark ? ArrowDoodle : StarDoodle;

  return (
    <section
      id={project.slug}
      className={clsx(
        "relative px-6 py-20 md:px-10 md:py-24 md:min-h-screen md:flex md:items-center overflow-hidden",
        isDark ? "sec-dark bg-dark text-ink-onDark" : "bg-cream text-ink-onCream"
      )}
    >
      <div className={clsx("max-w-6xl mx-auto w-full grid md:grid-cols-2 gap-8 md:gap-12 items-center", reverse && "md:[direction:rtl]")}>
        <div className={clsx(reverse && "md:[direction:ltr]")}>
          <div className="inline-flex items-center gap-3 flex-wrap">
            <p className={clsx("font-serif italic text-base", isDark ? "text-mustard" : "text-maroon")}>
              {project.index} · {project.year}
            </p>
            <Doodle className={clsx("pointer-events-none flex-shrink-0", isDark ? "text-mustard" : "text-maroon")} color="" />
          </div>
          <h3 className="font-serif font-extrabold text-[clamp(1.7rem,5.2vw,3rem)] leading-tight mt-2">{project.title}</h3>
          {project.subtitle && <p className="mt-2 text-xs uppercase tracking-wider opacity-65">{project.subtitle}</p>}
          <p className="mt-4 max-w-md text-[0.96rem] leading-relaxed opacity-85">{project.description}</p>

          {project.highlights.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2.5">
              {project.highlights.map((h) => (
                <span key={h} className="flex items-center gap-1.5 text-sm">
                  <span className={clsx("w-4 h-4 rounded-full flex items-center justify-center text-[10px] shrink-0", isDark ? "bg-mustard text-dark" : "bg-maroon text-white")}>
                    ✓
                  </span>
                  {h}
                </span>
              ))}
            </div>
          )}

          <div className="mt-6 flex flex-wrap gap-2.5">
            {project.tags.map((tag) => (
              <span key={tag} className={clsx("border rounded-sm px-3 py-1.5 text-xs uppercase tracking-wide", isDark ? "border-line-dark" : "border-line-cream")}>
                {tag}
              </span>
            ))}
          </div>

          <motion.ul
            id={`details-${project.slug}`}
            initial={false}
            animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }}
            transition={{ duration: 0.35 }}
            className="overflow-hidden list-disc pl-5 max-w-md text-[0.93rem] leading-relaxed opacity-90"
          >
            {project.details.map((d, i) => (
              <li key={d} className={i === 0 ? "mt-5" : "mt-1.5"}>
                {d}
              </li>
            ))}
          </motion.ul>
          {project.note && open && <p className="mt-3 text-xs opacity-60 max-w-md">{project.note}</p>}

          <div className="mt-7 flex flex-wrap gap-x-6 gap-y-3 text-sm font-semibold">
            <button
              type="button"
              aria-expanded={open}
              aria-controls={`details-${project.slug}`}
              onClick={() => setOpen((o) => !o)}
              className="border-b border-current pb-0.5"
            >
              {open ? "Hide Details −" : "View Project +"}
            </button>
            {project.liveUrl && (
              <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="border-b border-current pb-0.5">
                Visit Live Site →
              </a>
            )}
            {project.altUrl && (
              <a href={project.altUrl} target="_blank" rel="noopener noreferrer" className="border-b border-current pb-0.5">
                Alternate Demo →
              </a>
            )}
            {project.repoUrl && (
              <a href={project.repoUrl} target="_blank" rel="noopener noreferrer" className="border-b border-current pb-0.5">
                View Repository →
              </a>
            )}
            {project.liveSoonText && <span className="opacity-40 border-b border-dashed border-current pb-0.5">{project.liveSoonText}</span>}
            {project.repoSoonText && <span className="opacity-40 border-b border-dashed border-current pb-0.5">{project.repoSoonText}</span>}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className={clsx("relative h-[300px] md:h-[440px]", reverse && "md:[direction:ltr]")}
        >
          <TiltCard className="absolute inset-0">
            {project.images.length > 0 ? (
              <>
                <div className="absolute rounded-xl overflow-hidden shadow-2xl border-[6px] border-white top-[6%] left-[2%] w-[78%] h-[65%] z-10">
                  <Image src={project.images[0].src} alt={project.images[0].alt} fill sizes="(min-width:768px) 40vw, 90vw" className="object-cover object-top" />
                </div>
                {project.images[1] && (
                  <div
                    className="absolute rounded-2xl overflow-hidden shadow-2xl border-[6px] border-white bottom-0 right-[6%] w-[34%] h-[60%] rotate-6 z-20"
                    style={{ transform: "translateZ(40px) rotate(6deg)" }}
                  >
                    <Image src={project.images[1].src} alt={project.images[1].alt} fill sizes="25vw" className="object-cover object-top" />
                  </div>
                )}
              </>
            ) : (
              <div
                className={clsx(
                  "absolute rounded-xl top-[6%] left-[2%] w-[78%] h-[65%] flex flex-col items-center justify-center font-serif text-center px-4 border border-dashed",
                  isDark ? "bg-gradient-to-br from-maroon/20 to-maroon/5 border-line-dark" : "bg-gradient-to-br from-maroon/10 to-mustard/5 border-line-cream"
                )}
                role="img"
                aria-label={`Screenshot placeholder for ${project.title}`}
              >
                <span className="opacity-50">{project.title}</span>
                <span className="mt-2 text-xs font-body uppercase tracking-wider opacity-40">Screenshot coming soon</span>
              </div>
            )}
          </TiltCard>
        </motion.div>
      </div>
    </section>
  );
}
