"use client";

import { motion } from "framer-motion";
import { StarDoodle } from "./Doodles";
import { person, seeking } from "@/lib/data/site";

export default function Contact() {
  return (
    <section id="contact" className="sec-dark bg-dark text-ink-onDark px-6 py-28 md:px-10 md:py-32 text-center relative overflow-hidden">
      <StarDoodle className="absolute top-[10%] left-[8%]" />
      <p className="text-xs uppercase tracking-[0.22em] text-mustard font-semibold mb-3">Contact</p>
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="font-serif font-extrabold text-[clamp(2.1rem,7.6vw,4.4rem)] leading-tight"
      >
        Let&apos;s build something <em className="italic text-mustard font-bold">meaningful</em> together.
      </motion.h2>
      <p className="mt-6 text-[#cfc6b8] max-w-md mx-auto text-sm">I&apos;m currently seeking opportunities in:</p>
      <div className="mt-5 flex flex-wrap gap-2.5 justify-center">
        {seeking.map((s) => (
          <span key={s} className="border border-line-dark rounded-full px-4 py-2 text-xs text-[#e7e0d3]">
            {s}
          </span>
        ))}
      </div>
      <p className="mt-7 text-[#cfc6b8] max-w-md mx-auto text-sm">
        I&apos;m always excited to learn, collaborate, and contribute to impactful projects.
      </p>
      <div className="mt-10 flex gap-6 justify-center flex-wrap text-sm">
        <a href={person.github} target="_blank" rel="noopener noreferrer" className="border-b border-current pb-0.5">
          GitHub
        </a>
        <a href={person.linkedin} target="_blank" rel="noopener noreferrer" className="border-b border-current pb-0.5">
          LinkedIn
        </a>
        <a href={`mailto:${person.email}`} className="border-b border-current pb-0.5">
          Email
        </a>
        <span className="opacity-70">{person.phone}</span>
      </div>
    </section>
  );
}
