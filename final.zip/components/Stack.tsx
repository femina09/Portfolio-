"use client";

import { motion } from "framer-motion";
import { stack } from "@/lib/data/site";
import clsx from "clsx";
import TiltCard from "./TiltCard";

export default function Stack() {
  return (
    <section id="stack" className="px-6 py-24 md:px-10 md:py-28">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-11">
          <h2 className="font-serif font-bold text-[clamp(1.7rem,5.4vw,2.9rem)]">Craft &amp; stack</h2>
          <p className="font-hand text-[clamp(1.05rem,3vw,1.35rem)] text-maroon">— tools I actually reach for</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5" style={{ gridAutoRows: "120px" }}>
          {stack.map((cell, i) => (
            <motion.div
              key={cell.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className={clsx(cell.wide && "md:col-span-2", cell.tall && "md:row-span-2 min-h-[110px]")}
            >
              <TiltCard
                lift={5}
                className={clsx(
                "bento-cell h-full border rounded-md p-4 flex flex-col justify-between transition-colors",
                cell.dark
                  ? "bg-ink-onCream text-cream border-ink-onCream"
                  : "border-line-cream hover:bg-white hover:shadow-lg"
              )}
              >
              <p className={clsx("text-xs uppercase tracking-wider font-bold", cell.dark ? "text-mustard" : "text-maroon")}>
                {cell.label}
              </p>
              <p className={clsx("text-sm leading-snug", cell.dark ? "text-[#cfc6b8]" : "text-ink-onCreamMuted")}>
                {cell.items}
              </p>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
