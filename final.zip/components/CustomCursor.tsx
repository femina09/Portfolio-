"use client";

import { useEffect } from "react";

export default function CustomCursor() {
  useEffect(() => {
    const cursor = document.getElementById("custom-cursor");
    if (!cursor) return;

    const move = (e: MouseEvent) => {
      cursor.style.transform = `translate(${e.clientX - 15}px, ${e.clientY - 15}px)`;
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const darkSec = el && el.closest(".sec-dark");
      cursor.classList.toggle("on-dark", !!darkSec);
    };
    const over = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest("a, button, .h-card, .cert-card, .bento-cell")) {
        cursor.classList.add("hovering");
      }
    };
    const out = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest("a, button, .h-card, .cert-card, .bento-cell")) {
        cursor.classList.remove("hovering");
      }
    };

    window.addEventListener("mousemove", move);
    document.addEventListener("mouseover", over);
    document.addEventListener("mouseout", out);
    return () => {
      window.removeEventListener("mousemove", move);
      document.removeEventListener("mouseover", over);
      document.removeEventListener("mouseout", out);
    };
  }, []);

  return <div id="custom-cursor" className="hidden md:block" />;
}
