"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import TiltCard from "./TiltCard";
import { heroContent, person } from "@/lib/data/site";

const tocItems = [
  { n: "01", label: "About & Timeline", sec: "Sec. 02" },
  { n: "02", label: "Skills", sec: "Sec. 03" },
  { n: "03", label: "Experience & Internships", sec: "Sec. 04" },
  { n: "04", label: "Selected Projects", sec: "Sec. 05" },
  { n: "05", label: "Education & Certifications", sec: "Sec. 06–09" },
  { n: "06", label: "Say Hello", sec: "Sec. 10" },
];

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen px-6 pt-32 pb-16 md:px-10 md:pt-36 overflow-hidden">
      <div className="max-w-6xl mx-auto grid md:grid-cols-[1.3fr_0.9fr] gap-10 items-start relative">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-xs uppercase tracking-[0.22em] text-maroon font-semibold mb-5 leading-relaxed"
          >
            {heroContent.kicker}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-serif font-extrabold text-[clamp(2.1rem,7.2vw,5.2rem)] leading-[1.06] tracking-tight"
          >
            Femina Jacob builds <em className="italic font-semibold text-maroon">digital experiences</em> with code, creativity, and continuous learning.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 max-w-md text-ink-onCreamMuted text-[clamp(0.92rem,2.4vw,1.05rem)] leading-relaxed"
          >
            {heroContent.descriptionParts.join(" ")}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-8 flex flex-wrap gap-4"
          >
            <a
              href="#projects"
              className="btn-3d [--depth:#7A2036] inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold uppercase tracking-wide bg-ink-onCream text-cream hover:bg-maroon"
            >
              View Projects →
            </a>
            <a
              href={person.resume}
              download="Femina_Jacob_Resume.pdf"
              className="btn-3d inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold uppercase tracking-wide border border-ink-onCream text-ink-onCream hover:bg-ink-onCream hover:text-cream"
            >
              Download Résumé
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold uppercase tracking-wide text-maroon border-b border-maroon hover:text-ink-onCream hover:border-ink-onCream transition-colors"
            >
              Contact Me
            </a>
          </motion.div>

          <div className="mt-14 max-w-lg border-t border-line-cream pt-6">
            {tocItems.map((item) => (
              <div
                key={item.n}
                className="flex items-baseline gap-3 py-2 border-b border-line-cream text-sm"
              >
                <span className="font-serif italic text-maroon w-6 shrink-0">{item.n}</span>
                <span>{item.label}</span>
                <span className="flex-1 border-b border-dotted border-line-cream -translate-y-1" />
                <span className="text-xs text-ink-onCreamMuted whitespace-nowrap">{item.sec}</span>
              </div>
            ))}
          </div>
        </div>

        <TiltCard
          max={6}
          className="relative inline-block order-first md:order-none mb-8 md:mb-0 mx-auto"
        >
        <div
          className="relative"
          style={{ width: "clamp(220px, 28vw, 420px)", aspectRatio: "1" }}
        >
          {/* Floating skill tokens at different depths (decorative; real skills only) */}
          {[
            ["React.js", "top-[4%] -left-[14%]", "0s", 50],
            ["Django", "top-[46%] -right-[16%]", "1.2s", 70],
            ["Python", "bottom-[2%] left-[2%]", "2.1s", 40],
            ["Kotlin", "top-[-2%] right-[10%]", "0.6s", 60],
          ].map(([label, pos, delay, z]) => (
            <span
              key={label as string}
              aria-hidden="true"
              className={`float-chip hidden md:block absolute z-[4] ${pos} bg-white border border-line-cream rounded-sm px-3 py-1.5 text-xs uppercase tracking-wide text-maroon shadow-lg`}
              style={{ animationDelay: delay as string, transform: `translateZ(${z}px)` }}
            >
              {label}
            </span>
          ))}
          <div
            className="absolute inset-0 z-[2] rounded-full overflow-hidden border-[6px] border-cream"
            style={{ boxShadow: "0 22px 44px rgba(122,32,54,0.2)" }}
          >
            <Image src="/images/profile.jpg" alt="Femina Jacob" fill className="object-cover" priority />
          </div>
          {/* Ring, arrow, and both handwritten labels live in ONE svg / ONE
              coordinate space, so they scale together as a single unit and
              can never drift apart from each other or from the photo. */}
          <svg
            className="absolute z-[3] pointer-events-none"
            style={{ top: "-20%", left: "-20%", width: "140%", height: "140%" }}
            viewBox="0 0 140 140"
            preserveAspectRatio="xMidYMid meet"
          >
            <path
              d="M70 12 C 96 13, 118 34, 119 62 C 120 92, 98 119, 71 120 C 44 121, 13 98, 12 70 C 11 43, 45 11, 70 12 Z"
              stroke="#7A2036" strokeWidth="1.3" fill="none" opacity="0.55"
            />
            <path d="M118 10 Q 117 20, 111 28" stroke="#7A2036" strokeWidth="1.6" fill="none" strokeLinecap="round" />
            <path d="M118 26 L111 28 L112 21" stroke="#7A2036" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            <text x="55" y="8" fontSize="9" fill="#7A2036" fontFamily="var(--font-caveat), cursive" transform="rotate(-6 82 8)">
              final-year CSE
            </text>
            <text x="4" y="118" fontSize="9" fill="#7A2036" fontFamily="var(--font-caveat), cursive" transform="rotate(5 20 118)">
              builder
            </text>
          </svg>
        </div>
        </TiltCard>
      </div>

      <div className="absolute bottom-6 left-6 md:left-10 text-xs uppercase tracking-[0.22em] text-ink-onCreamMuted flex items-center gap-3">
        <span className="w-9 h-px bg-current" /> Scroll to read
      </div>
    </section>
  );
}
