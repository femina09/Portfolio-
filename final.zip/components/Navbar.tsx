"use client";

import { useState } from "react";
import { motion } from "framer-motion";

const links = [
  { label: "Home", href: "#hero" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#stack" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Education", href: "#education" },
  { label: "Certifications", href: "#certs" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 inset-x-0 z-50 px-6 py-4 md:px-10 md:py-4 bg-cream/85 backdrop-blur-md border-b border-line-cream"
    >
      <div className="flex items-center justify-between">
        <a href="#hero" className="font-serif text-xl font-bold text-ink-onCream">
          Femina<span className="text-maroon">.</span>
        </a>
        <nav aria-label="Main" className="hidden lg:flex gap-6 text-sm">
          {links.slice(1).map((l) => (
            <a key={l.href} href={l.href} className="text-ink-onCreamMuted hover:text-maroon transition-colors">
              {l.label}
            </a>
          ))}
        </nav>
        <button
          type="button"
          className="lg:hidden w-10 h-10 flex flex-col items-center justify-center gap-1.5 text-ink-onCream"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((o) => !o)}
        >
          <span className={`block w-6 h-0.5 bg-current transition-transform ${open ? "translate-y-2 rotate-45" : ""}`} />
          <span className={`block w-6 h-0.5 bg-current transition-opacity ${open ? "opacity-0" : ""}`} />
          <span className={`block w-6 h-0.5 bg-current transition-transform ${open ? "-translate-y-2 -rotate-45" : ""}`} />
        </button>
      </div>
      {open && (
        <nav id="mobile-menu" aria-label="Mobile" className="lg:hidden mt-4 pb-2 flex flex-col border-t border-line-cream">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="py-3 border-b border-line-cream font-serif text-lg text-ink-onCream hover:text-maroon"
            >
              {l.label}
            </a>
          ))}
        </nav>
      )}
    </motion.header>
  );
}
