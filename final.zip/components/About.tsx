"use client";

import { motion } from "framer-motion";
import { StarDoodle } from "./Doodles";
import { aboutContent, timeline } from "@/lib/data/site";

export default function About() {
  return (
    <section id="about" className="sec-dark relative bg-dark text-ink-onDark px-6 py-24 md:px-10 md:py-28 overflow-hidden">
      <div className="max-w-5xl mx-auto relative">
        <StarDoodle className="absolute -top-8 left-[6%]" />
        <p className="text-xs uppercase tracking-[0.22em] text-mustard font-semibold mb-3">About</p>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="font-serif italic font-medium text-[clamp(1.35rem,4.4vw,2.5rem)] leading-snug max-w-3xl"
        >
          &ldquo;{aboutContent.quote}&rdquo;
        </motion.p>

        <div className="mt-9 max-w-2xl flex flex-col gap-4">
          {aboutContent.paragraphs.map((p) => (
            <p key={p} className="text-ink-onDarkMuted leading-relaxed">
              {p}
            </p>
          ))}
        </div>

        <div className="mt-16 flex flex-col">
          {timeline.map((item, i) => (
            <motion.div
              key={item.year}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="grid grid-cols-1 sm:grid-cols-[110px_1fr] gap-2 sm:gap-6 border-t border-line-dark py-6"
            >
              <p className="font-serif italic text-2xl text-mustard">{item.year}</p>
              <div className="flex flex-col gap-1.5">
                {item.lines.map((line, idx) => (
                  <p
                    key={line}
                    className={idx === 0 && item.lines.length > 1 ? "font-semibold text-ink-onDark" : "text-[#e7e0d3]"}
                  >
                    {line}
                  </p>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
