# Femina Jacob — Editorial Portfolio

Next.js 15 + TypeScript + Tailwind CSS + Framer Motion. A single-page, magazine-style
portfolio: cream/near-black/maroon palette, serif display headings, hand-drawn doodle
accents, and full-screen alternating case studies — built from your real resume content.

## Getting started

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # static export -> ./out (index.html at its root)
npm start          # preview ./out locally
```

Requires Node 20+. Fonts (Inter, Playfair Display, Caveat) are self-hosted in `app/fonts/`, so builds need no network access to Google Fonts.

## Deploying to Netlify

**Manual:** unzip `femina-portfolio-netlify-deploy.zip`, then drag the extracted folder (the one that contains `index.html`) onto https://app.netlify.com/drop, or use Deploys > "Deploy manually".

**Git-connected:** `netlify.toml` already sets build command `npm run build` and publish directory `out`.

## Structure

```
app/
  layout.tsx        Fonts (Playfair Display, Inter, Caveat), SEO metadata, JSON-LD
  page.tsx           Assembles every section in order
components/
  Hero, About, Stack, CaseStudySection, Gallery, Achievements, Certifications, Contact, Footer
  Doodles.tsx         Reusable hand-drawn arrow/star/circle SVGs
  CustomCursor.tsx    Mouse-tracking cursor that adapts to light/dark sections
lib/data/
  site.ts             Bio, timeline, stack, stats, certifications, seeking list
  projects.ts         The 4 featured case studies + the More Work gallery items
public/
  images/             Profile photo + real project screenshots
  resume.pdf          Your actual uploaded résumé
```

## Updating content

- `lib/data/site.ts` — bio, timeline, skills, experience, education, certifications, achievements, stats.
- `lib/data/projects.ts` — the 7 projects (newest first). To add screenshots, put files in `public/images/projects/`
  and list them in that project's `images` array. Empty array = "Screenshot coming soon" placeholder, same layout.
- Filtering, tilt, scroll progress, back-to-top, floating chips and wireframe cubes are in `components/`.
