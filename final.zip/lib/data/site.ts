import { certifications } from "./certifications";

export const person = {
  name: "Femina Jacob",
  role: "Software Engineer | Full-Stack Developer",
  email: "feminajacob09@gmail.com",
  phone: "+91 8122476409",
  github: "https://github.com/femina09",
  linkedin: "https://www.linkedin.com/in/femina-jacob",
  resume: "/resume.pdf",
};

export const heroContent = {
  kicker: "Final-Year CSE Student · Full-Stack · Mobile · AI/ML",
  descriptionParts: [
    "Final-year Computer Science and Engineering student with 1+ year of internship experience in full-stack, web, and mobile application development.",
    "I build production-oriented applications and AI/ML systems, and I'm seeking Software Engineer / Full-Stack Developer opportunities.",
  ],
};

export const aboutContent = {
  quote:
    "I believe great software is more than writing code — it solves real problems, creates meaningful experiences, and keeps people at the center of every decision.",
  paragraphs: [
    "Final-year B.E. Computer Science and Engineering student at Grace College of Engineering with 1+ year of internship experience across full-stack, web, and mobile development.",
    "I work with Java, Python, JavaScript, React.js, Django, REST APIs, SQL, and AI/ML, and I\'ve built production-oriented applications including a custom Shopify storefront for a live client, a voice-assistant Android app integrating 5+ REST APIs, and an NLP-based spam detection system.",
    "I have a strong foundation in software development, problem-solving, and Agile practices, with project and hackathon experience in AI, web development, and IoT.",
  ],
};

export interface TimelineItem {
  year: string;
  lines: string[];
}

export const timeline: TimelineItem[] = [
  {
    year: "2023",
    lines: [
      "Started B.E. Computer Science & Engineering",
      "Grace College of Engineering",
      "Built the IoT Air Quality Monitoring System",
    ],
  },
  {
    year: "2024",
    lines: [
      "Django Web Development Internship (Jan – Mar)",
      "Built a full-stack E-Commerce Platform (React.js, Django, PostgreSQL)",
      "Began the Voice Assistant Android app",
    ],
  },
  {
    year: "2025",
    lines: [
      "Mobile Application Development Internship at NullClass (Apr – Sep)",
      "Built the AI-Powered Spam SMS Detection System",
      "Presented at a national-level hackathon",
    ],
  },
  {
    year: "2026",
    lines: [
      "Samsung Innovation Campus AI Training, Shopify live client project, EvalBench internship, PromptWars Generative AI Challenge, Elevance Skills training, RedBus clone, and ELVARIX\'26 symposium platform.",
    ],
  },
];

export interface StackCategory {
  label: string;
  items: string;
  wide?: boolean;
  tall?: boolean;
  dark?: boolean;
}

export const stack: StackCategory[] = [
  {
    label: "Languages",
    items: "Java · JavaScript · Python · SQL · HTML · CSS · C++",
    wide: true,
    tall: true,
    dark: true,
  },
  { label: "Frontend", items: "React.js · Angular · Responsive Web Design" },
  { label: "Backend", items: "Django · Express.js · Node.js · REST APIs" },
  { label: "Databases", items: "MySQL · MongoDB · PostgreSQL" },
  { label: "Cloud", items: "AWS (EC2, S3, IAM) — currently learning" },
  { label: "AI / Machine Learning", items: "Scikit-learn · Pandas · NumPy · TF-IDF · Naive Bayes", wide: true },
  { label: "Tools", items: "Git · GitHub · VS Code · Figma · Shopify · Postman", wide: true },
  { label: "Deployment", items: "Netlify · Vercel · Hostinger", wide: true },
  { label: "Concepts", items: "OOP · DBMS · Operating Systems · Computer Networks", wide: true },
];

export interface Stat {
  label: string;
  value?: number;
  suffix?: string;
  text?: string;
}

export const stats: Stat[] = [
  { label: "Internships & Training", value: 4 },
  { label: "Projects", value: 7 },
  { label: "Certifications", value: certifications.length },
  { label: "Conference Presentations", value: 2 },
  { label: "Hackathon Participations", value: 2 },
  { label: "CSE Student", text: "Final Year" },
];

export const achievements: { label: string; title: string; detail: string }[] = [
  { label: "Paper Presenter", title: "National Conference on Emerging Technologies", detail: "“Future of Virtual Reality”" },
  { label: "Paper Presenter", title: "National Conference on Engineering & Innovation", detail: "“Air Quality Monitoring System”" },
  { label: "Hackathon", title: "IoT Air Quality Monitoring System", detail: "1st year" },
  { label: "Hackathon", title: "AI Spam Detection for Cybersecurity", detail: "3rd year" },
];

export interface Experience {
  role: string;
  org: string;
  dates: string;
  tags: string[];
  details: string[];
  link?: { label: string; href: string };
}

export const experiences: Experience[] = [
  {
    role: "Full Stack Web Development Trainee",
    org: "Elevance Skills",
    dates: "Jul 10, 2026 – Oct 9, 2026 · 4 months",
    tags: ["Angular", "Express.js", "MongoDB", "Netlify"],
    details: [
      "Completed a 4-month online Full Stack Web Development training and received a Certificate of Training (Oct 4, 2026).",
      "Built a RedBus-style website through real-time project training, applying front-end and back-end concepts end to end.",
      "Deployed the project on Netlify as a live, publicly accessible site.",
    ],
    link: { label: "RedBus project", href: "https://redbus-cloneweb.netlify.app/" },
  },
  {
    role: "Web Development Intern",
    org: "EvalBench Technologies Pvt. Ltd.",
    dates: "Jun 2026 – Aug 2026 · 2 months",
    tags: ["Front-End", "Back-End", "Git"],
    details: [
      "Completed a 2-month online industry internship in front-end and back-end web development under experienced mentors.",
      "Built responsive web applications with modern web technologies.",
      "Collaborated in a production-style environment, improving problem-solving, debugging, and code quality.",
      "Gained hands-on experience with Git, project workflows, and professional development practices.",
    ],
  },
  {
    role: "Mobile Application Development Intern",
    org: "NullClass",
    dates: "Apr 2025 – Sep 2025 · 6 months",
    tags: ["Kotlin", "Java", "Android Studio", "Speech-to-Text API", "REST APIs"],
    details: [
      "Designed and shipped a real-time voice-assistant Android app with Google Speech-to-Text and NLP-based intent parsing.",
      "Integrated 5+ RESTful APIs and achieved sub-500ms response time across varied Android device form factors.",
      "Implemented UI components to Material Design standards.",
      "Contributed to Agile sprints: code reviews, technical documentation, and retrospectives, as part of a distributed team.",
    ],
  },
  {
    role: "Django Web Development Intern",
    org: "Industry Internship",
    dates: "Jan 2024 – Mar 2024 · 3 months",
    tags: ["Python", "Django", "PostgreSQL", "JavaScript", "Git"],
    details: [
      "Built and maintained web applications using Django\'s MVT architecture, following PEP8 standards.",
      "Designed relational schemas in PostgreSQL/SQLite and wrote optimized queries.",
      "Developed RESTful API endpoints consumed by a JavaScript frontend.",
      "Applied Git branching strategies and took part in structured peer code reviews.",
    ],
  },
];

export const education = {
  degree: "B.E. Computer Science and Engineering",
  school: "Grace College of Engineering",
  years: "2023 – 2027 (Expected)",
  coursework: ["Data Structures & Algorithms", "Object-Oriented Programming", "DBMS", "Operating Systems", "Computer Networks", "Machine Learning", "UI/UX Design", "Web Technologies"],
};

export const seeking = [
  "Software Engineering",
  "Full-Stack Development",
  "AI / Machine Learning",
  "Web Development",
];
