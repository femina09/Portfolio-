export type CertCategory =
  | "Programming & Development"
  | "AI & Machine Learning"
  | "UI/UX Design"
  | "Workshops & Training"
  | "Competitions & Achievements";

export interface Certification {
  slug: string;
  title: string;
  issuer: string;
  /** Exactly as printed on the certificate (or the resume, where no image has been uploaded yet). */
  date?: string;
  category?: CertCategory;
  initials: string;
  /** Facts taken from the certificate itself. */
  description?: string;
  /** Add `image` once the certificate file is in /public/images/certificates/. */
  image?: { src: string; width: number; height: number };
}

export const certCategories: CertCategory[] = [
  "Programming & Development",
  "AI & Machine Learning",
  "UI/UX Design",
  "Workshops & Training",
  "Competitions & Achievements",
];

/** Newest first; undated certificates follow the dated ones. */
export const certifications: Certification[] = [
  {
    slug: "elevance-full-stack-web-development",
    title: "Full Stack Web Development — Certificate of Training",
    issuer: "Elevance Skills",
    date: "Issued Oct 4, 2026",
    category: "Programming & Development",
    initials: "FS",
    description: "Online training on Full Stack Web Development and real-time project training on “Learn To Build A Real Website Like RedBus”.",
    image: { src: "/images/certificates/elevance-full-stack-web-development-certificate-of-training.jpg", width: 1079, height: 974 },
  },
  {
    slug: "promptwars-generative-ai-challenge-3",
    title: "PromptWars Virtual — Generative AI Challenge 3 (Certificate of Appreciation)",
    issuer: "Google for Developers / H2S",
    date: "11/08/2026",
    category: "Competitions & Achievements",
    initials: "PW",
    description: "Recognises a successful submission of a verified Generative AI solution for Challenge 3 during PromptWars Virtual.",
    image: { src: "/images/certificates/google-h2s-promptwars-virtual-generative-ai-challenge-3.jpg", width: 1079, height: 804 },
  },
  {
    slug: "tata-genai-data-analytics-job-simulation",
    title: "GenAI Powered Data Analytics Job Simulation",
    issuer: "Tata · Forage",
    date: "July 7, 2026",
    category: "AI & Machine Learning",
    initials: "TG",
    description: "Certificate of Completion. Practical tasks: exploratory data analysis and risk profiling, predicting delinquency with AI, business report and data storytelling for collections strategy, and implementing an AI-driven collections strategy.",
    image: { src: "/images/certificates/tata-forage-genai-powered-data-analytics-job-simulation.jpg", width: 1080, height: 746 },
  },
  {
    slug: "niesbud-solar-entrepreneurship-esdp",
    title: "ESDP on Solar Entrepreneurship (PM SG: MBY)",
    issuer: "National Institute for Entrepreneurship and Small Business Development (NIESBUD)",
    date: "23 Feb 2026 – 03 Mar 2026",
    category: "Workshops & Training",
    initials: "SE",
    description: "Entrepreneurship Skill Development Programme conducted at Tuticorin, Tamil Nadu. Issued 03 March 2026.",
    image: { src: "/images/certificates/niesbud-esdp-solar-entrepreneurship.jpg", width: 1080, height: 760 },
  },
  {
    slug: "samsung-innovation-campus-ai",
    title: "Samsung Innovation Campus — Artificial Intelligence",
    issuer: "Samsung · ESSCI",
    date: "5/01/2026 – 28/02/2026",
    category: "AI & Machine Learning",
    initials: "SI",
    description: "Certificate of Completion for the Artificial Intelligence course of Samsung Innovation Campus.",
    image: { src: "/images/certificates/samsung-innovation-campus-artificial-intelligence.jpg", width: 1080, height: 737 },
  },
  {
    slug: "react-js",
    title: "ReactJS — Course Completion Certificate",
    issuer: "Infosys Springboard",
    date: "February 16, 2026",
    category: "Programming & Development",
    initials: "RJ",
    image: { src: "/images/certificates/infosys-springboard-reactjs.jpg", width: 1080, height: 762 },
  },
  {
    slug: "mongodb-basics-for-students",
    title: "MongoDB Basics for Students — Proof of Completion",
    issuer: "MongoDB",
    date: "08-18-2025",
    category: "Programming & Development",
    initials: "MB",
    image: { src: "/images/certificates/mongodb-basics-for-students.jpg", width: 1079, height: 826 },
  },
  {
    slug: "ai-tools-chatgpt-workshop",
    title: "AI Tools & ChatGPT Workshop",
    issuer: "be10X",
    date: "August 17, 2025",
    category: "Workshops & Training",
    initials: "GP",
    description: "Certificate of Completion for the AI tools and ChatGPT workshop.",
    image: { src: "/images/certificates/be10x-ai-tools-chatgpt-workshop.jpg", width: 1080, height: 686 },
  },
  {
    slug: "figma-bootcamp",
    title: "Figma Bootcamp",
    issuer: "Lets Upgrade (with NSDC, ITM Edutech Training and GDG MAD)",
    date: "17 – 19 July 2025 (3 days)",
    category: "UI/UX Design",
    initials: "FG",
    image: { src: "/images/certificates/letsupgrade-figma-bootcamp.jpg", width: 1080, height: 758 },
  },
  {
    slug: "aws-solutions-architecture-job-simulation",
    title: "Solutions Architecture Job Simulation",
    issuer: "AWS · Forage",
    date: "July 16, 2025",
    category: "Programming & Development",
    initials: "AW",
    description: "Certificate of Completion. Practical task: designing a simple, scalable hosting architecture.",
    image: { src: "/images/certificates/aws-forage-solutions-architecture-job-simulation.jpg", width: 1080, height: 766 },
  },
  {
    slug: "ai-masterclass",
    title: "Freedom with AI Masterclass",
    issuer: "Freedom with AI",
    date: "12/07/2025",
    category: "AI & Machine Learning",
    initials: "AM",
    description: "Certificate of Completion for the Freedom with AI Masterclass.",
    image: { src: "/images/certificates/freedom-with-ai-masterclass.jpg", width: 1080, height: 742 },
  },
  {
    slug: "outskill-ai-for-engineers",
    title: "AI for Engineers",
    issuer: "Outskill",
    category: "AI & Machine Learning",
    initials: "AE",
    description: "Certificate of Completion.",
    image: { src: "/images/certificates/outskill-ai-for-engineers.jpg", width: 1079, height: 654 },
  },
  {
    slug: "ux-design",
    title: "Digital Skills: User Experience",
    issuer: "Accenture (FutureLearn)",
    category: "UI/UX Design",
    initials: "UX",
    description: "Certificate of Achievement. An online introduction to user experience (UX), 3 weeks, 2 hours per week.",
    image: { src: "/images/certificates/accenture-futurelearn-digital-skills-user-experience.jpg", width: 1080, height: 1048 },
  },
  {
    slug: "icraisetm-2024-paper-presentation",
    title: "Paper Presentation: “Air Quality Monitoring System” — ICRAISETM-2024",
    issuer: "Solamalai College of Engineering, Madurai · ICT Academy",
    date: "26 & 27 April 2024",
    category: "Competitions & Achievements",
    initials: "CP",
    description: "Certificate of Appreciation from the 2nd International Conference on Recent Advances and Innovations in Science, Engineering, Technology and Management (ICRAISETM-2024).",
    image: { src: "/images/certificates/solamalai-icraisetm-2024-paper-presentation-air-quality-monitoring.jpg", width: 1079, height: 722 },
  },
  // Listed on the resume; certificate images not uploaded yet (shown without a preview).
  { slug: "ai-for-the-future", title: "AI for the Future", issuer: "Course certification", category: "AI & Machine Learning", initials: "AI" },
  { slug: "next-gen-vr", title: "Next Gen VR", issuer: "Course certification", initials: "VR" },
];
