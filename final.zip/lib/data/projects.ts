export interface CaseStudy {
  slug: string;
  index: string;
  year: string;
  category: "Full-Stack" | "E-Commerce" | "AI/ML" | "Mobile" | "IoT";
  title: string;
  subtitle?: string;
  description: string;
  highlights: string[];
  details: string[];
  tags: string[];
  liveUrl?: string;
  altUrl?: string;
  repoUrl?: string;
  liveSoonText?: string;
  repoSoonText?: string;
  note?: string;
  /**
   * SCREENSHOTS: drop image files into /public/images/projects/ and list them here,
   * e.g. { src: "/images/projects/redbus-1.jpg", alt: "RedBus search page" }.
   * An empty array shows the dashed placeholder; the card layout stays the same.
   */
  images: { src: string; alt: string }[];
}

export const caseStudies: CaseStudy[] = [
  {
    slug: "redbus-clone",
    index: "Case Study — 01",
    year: "2026",
    category: "Full-Stack",
    title: "RedBus Clone — Bus Booking Website",
    subtitle: "Angular · Express.js · MongoDB (MEAN)",
    description:
      "A RedBus-inspired bus-booking website built as a full-stack project during Elevance Skills web development training, with an Angular interface and an Express.js and MongoDB back end.",
    highlights: ["MEAN Stack", "Full-Stack", "Live on Netlify"],
    details: [
      "Developed a RedBus-inspired bus-booking website using the MEAN stack.",
      "Built the user-facing interface with Angular, backed by an Express.js and MongoDB back end.",
      "Deployed the front end on Netlify as a live, publicly accessible site.",
    ],
    tags: ["Angular", "Express.js", "MongoDB"],
    liveUrl: "https://redbus-cloneweb.netlify.app/",
    repoSoonText: "Repository coming soon",
    images: [
      { src: "/images/projects/redbus-desktop.jpg", alt: "RedBus clone home page with bus search, desktop view" },
      { src: "/images/projects/redbus-mobile.jpg", alt: "RedBus clone home page with bus search, mobile view" },
    ],
  },
  {
    slug: "elvarix-26",
    index: "Case Study — 02",
    year: "2026",
    category: "Full-Stack",
    title: "ELVARIX’26 — Symposium Website & Registration Platform",
    subtitle: "National-level symposium · Sep 1–16, 2026",
    description:
      "The official website and registration platform for ELVARIX’26, a national-level college symposium, independently developed and deployed as a live site.",
    highlights: ["Event Pages", "Registration Flow", "Responsive UI"],
    details: [
      "Independently developed and deployed the official website and registration platform.",
      "Built event information and end-to-end participant registration covering multiple technical and non-technical events.",
      "Designed a responsive, interactive UI that works consistently across desktop and mobile.",
    ],
    tags: ["Web Development", "Registration Workflow", "Responsive Design"],
    liveUrl: "https://elvarix26.web.app/",
    altUrl: "https://elvarix26.netlify.app",
    repoSoonText: "Repository private",
    images: [
      { src: "/images/projects/elvarix-desktop.jpg", alt: "ELVARIX’26 symposium website, desktop home page" },
      { src: "/images/projects/elvarix-mobile.jpg", alt: "ELVARIX’26 symposium website, mobile home page" },
    ],
  },
  {
    slug: "shopify-storefront",
    index: "Case Study — 03",
    year: "2026",
    category: "E-Commerce",
    title: "Shopify B2C E-Commerce Storefront",
    subtitle: "Live Client Project",
    description:
      "A custom Shopify Online Store 2.0 theme spanning 60+ Liquid/JSON files, delivered for a live client and passing Shopify’s theme validation with zero errors.",
    highlights: ["60+ Liquid/JSON files", "Zero validation errors", "Live client"],
    details: [
      "Developed a custom Shopify Online Store 2.0 theme for a live client.",
      "Worked across 60+ Liquid/JSON files and passed Shopify theme validation with zero errors.",
      "Diagnosed and fixed production defects (font rendering, Liquid form types, locale paths) before launch.",
    ],
    tags: ["Shopify Liquid", "Online Store 2.0", "JSON Templates"],
    liveSoonText: "Store temporarily offline",
    repoSoonText: "Repository private",
    note: "The store is offline while hosting is paused, so no live link is shown.",
    images: [
      { src: "/images/faithstore-desktop.jpg", alt: "Shopify storefront desktop view" },
      { src: "/images/faithstore-mobile.jpg", alt: "Shopify storefront mobile view" },
    ],
  },
  {
    slug: "spam-sms-detection",
    index: "Case Study — 04",
    year: "2025",
    category: "AI/ML",
    title: "AI-Powered Spam SMS Detection System",
    subtitle: "Python · NLP · Naive Bayes",
    description:
      "An NLP pipeline and Naive Bayes classifier for spam vs. ham SMS detection, presented at a national-level hackathon on practical AI in cybersecurity.",
    highlights: ["TF-IDF", "Naive Bayes", "Precision / Recall / F1"],
    details: [
      "Built an NLP pipeline with tokenization and stop-word removal.",
      "Used TF-IDF and Naive Bayes for SMS classification.",
      "Evaluated performance using precision, recall, and F1-score.",
      "Presented at a national-level hackathon.",
    ],
    tags: ["Python", "NLP", "Naive Bayes", "Scikit-learn", "Pandas"],
    repoUrl: "https://github.com/femina09/AI-Based-Spam-SMS-detection-using-navie-bayes",
    images: [{ src: "/images/spam-app.jpg", alt: "Spam SMS detection app" }],
  },
  {
    slug: "voice-assistant",
    index: "Case Study — 05",
    year: "2024–2025",
    category: "Mobile",
    title: "Voice Assistant Android App — Google Assistant Clone",
    subtitle: "Kotlin · Java · Android Studio",
    description:
      "A voice-based Android assistant integrating Google Speech-to-Text with NLP intent parsing for real-time, hands-free commands.",
    highlights: ["5+ REST APIs", "Sub-500ms response", "NLP intent parsing"],
    details: [
      "Integrated Google Speech-to-Text with NLP intent parsing.",
      "Integrated 5+ REST APIs using a modular Kotlin/Java architecture.",
      "Achieved sub-500ms response time on physical devices.",
    ],
    tags: ["Kotlin", "Java", "Android Studio", "Speech-to-Text API"],
    repoUrl: "https://github.com/femina09/google-assistant",
    images: [
      { src: "/images/projects/voice-assistant-desktop.jpg", alt: "Google Assistant welcome screen, “Hi! How can I help?”" },
      { src: "/images/projects/voice-assistant-mobile.jpg", alt: "Voice assistant conversation on a phone" },
    ],
  },
  {
    slug: "ecommerce-website",
    index: "Case Study — 06",
    year: "2024",
    category: "E-Commerce",
    title: "Full-Stack E-Commerce Platform",
    subtitle: "React.js · Django · PostgreSQL",
    description:
      "A full-stack shopping platform connecting a React.js frontend to a Django REST API with PostgreSQL, delivering product catalog, cart, and checkout workflows.",
    highlights: ["Product Catalog", "Cart & Checkout", "JWT Auth", "Responsive Design"],
    details: [
      "Built a full-stack shopping platform with a React.js frontend connected to Django REST APIs.",
      "Implemented product catalog, cart, and checkout workflows.",
      "Used PostgreSQL and JWT authentication to secure sessions and API endpoints, with a responsive Bootstrap UI.",
    ],
    tags: ["React.js", "Django", "PostgreSQL", "JWT", "Bootstrap"],
    liveUrl: "https://luxuryfurniture-e-commerce.netlify.app/",
    altUrl: "https://frabjous-profiterole-308260.netlify.app/",
    repoSoonText: "Repository coming soon",
    images: [
      { src: "/images/ecommerce-hero.jpg", alt: "E-commerce homepage hero" },
      { src: "/images/ecommerce-blog.jpg", alt: "E-commerce blog section" },
    ],
  },
  {
    slug: "air-quality-iot",
    index: "Case Study — 07",
    year: "2023",
    category: "IoT",
    title: "IoT Air Quality Monitoring System",
    subtitle: "Python · IoT Sensors · Real-Time Dashboard",
    description:
      "A sensor-based monitoring system streaming multi-parameter air quality data to a real-time dashboard, with automated alerts for unsafe pollutant levels.",
    highlights: ["Real-Time Dashboard", "Threshold Alerts", "National Conference"],
    details: [
      "Collected multi-parameter environmental data from IoT sensors.",
      "Implemented real-time dashboard monitoring.",
      "Added automated threshold alerts for unsafe pollutant levels.",
      "Presented at a national conference and hackathon focused on environmental impact and innovation.",
    ],
    tags: ["Python", "IoT Sensors", "Real-Time Dashboard"],
    repoSoonText: "Repository coming soon",
    images: [{ src: "/images/airquality-hw.jpg", alt: "Air quality monitoring hardware" }],
  },
];

export interface GalleryItem {
  title: string;
  label: string;
  anchor?: string;
  liveUrl?: string;
  repoUrl?: string;
  comingSoon?: boolean;
  image?: string;
}

/** "More work" strip: every case study (newest first) plus earlier side projects kept from the original site. */
export const galleryItems: GalleryItem[] = [
  ...caseStudies.map((c) => ({
    title: c.title.split(" — ")[0],
    label: `${c.category} · ${c.year}`,
    anchor: `#${c.slug}`,
    image: c.images[0]?.src,
  })),
  { title: "Lumière E-commerce Website", label: "React · Side project", liveUrl: "https://elite-commerce-lab-1.emergent.host", image: "/images/lumiere-hero.jpg" },
  { title: "Portfolio Website", label: "Next.js · This site", image: "/images/portfolio-hero.jpg" },
];
