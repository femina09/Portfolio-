/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Static export: `npm run build` writes a plain HTML/CSS/JS site to ./out (index.html at its root).
  output: "export",
  // Each route becomes <route>/index.html, which works on Netlify and any static host.
  trailingSlash: true,
  // No image-optimization server on static hosting; images are served as-is.
  images: { unoptimized: true },
};

export default nextConfig;
